Attention, before you start:

1. This toolbox is to be used on ImageJFIJI, not ImageJ.

2. This toolbox is designed based on the assumption that a horizontal OD OCT displays Temporal-to-Nasal and an OS OCT displays Nasal-to-Temporal, from left to right, with optic nerve at bottom of the image. If your image isn't like this please flip it first. Or go to "7.Developer's Box" and use "Change Default settings" to completely reset the basic setting. You can also change it back anytime.

3. This toolbox is designed based on the assumption that both vertical OD and OS OCT images displays Inferior-to-Superior, from left to right, with optic nerve at bottom of the image. If your image isn't like this please flip it first. Or go to "7.Developer's Box" and use "Change Default settings" to completely reset the basic setting. You can also change it back anytime.

4. Axial/lateral scales in um/pixel significantly affects your results. Please be careful with your inputs. These scales may differ from your original resolution depending on your image reporting method.